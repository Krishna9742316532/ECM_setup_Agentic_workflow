---
name: ecm-fit-check
description: Run an ECM parameter fit on a voltage/current dataset and check that the result is physically reasonable before reporting it. Use when asked to fit, re-fit or compare ECM parameters (R0, R1, tau, Q, SOC0) in this project.
---

# ECM fit + plausibility check

Use this every time ECM parameters are fitted or re-fitted. Do the steps in
order and do not skip the checks. Report problems, do not hide them.

## 1. Before fitting: check the data

1. Load with `ecm.data.load_mat` (or build a `CellData`).
2. Run `ecm.data.check_data(d)`. Stop and report if the list is not empty.
3. Confirm the sign convention: negative current = discharge.
   `current_step_resistance(d)` must be positive.
4. Estimate the noise: `estimate_noise_std(d.V, d.I)`. Write it down; it is
   the target RMSE.
5. After any Coulomb counting, run `check_soc_direction(I, soc)`: SOC must
   fall on discharge.
6. Confirm the data is public or synthetic. Never use company data.

## 2. Check the methods on synthetic data first

Run `pytest tests/test_identify.py`. All tests must pass. If you changed any
method, add or update a recovery test with known parameters.

## 3. Fit

```bash
PYTHONPATH=src python -m ecm.pipeline --data <file> --out results
```

or call `ecm.pipeline.run(d, out_dir, Settings())` from Python. Fit on
t < split and validate on t >= split. Never tune on the validation part.

## 4. Check the result (all must be answered in the report)

| Check | Pass condition | Where to look |
|---|---|---|
| Signs | R0, R_i, tau_i, Q > 0 | findings in `summary.md` |
| Ranges | inside `config.RANGES`, not on a bound | findings, `at_bound` |
| Fit error | fit RMSE ≈ noise (not much lower = overfit) | `summary.md` |
| Validation error | val RMSE < 1.3 × noise | `summary.md` |
| Residuals | no slow drift, ACF inside the band | `residuals.png`, `voltage_fit.png` |
| Identifiability | RC branch RMS voltage > noise; tau-scan has a clear minimum; NLS std small vs value | `tau_scan.png`, `std_errors` |
| Method agreement | NLS, separable LS and fixed-tau RLS agree; ARX may differ (noise bias) | method table |
| Model choice | lowest BIC among plausible models | model selection table |
| Capacity | Q stable across windows | capacity sensitivity table |
| OCV model | compared (`linear`, `poly10`, …); the chosen one gives white residuals and stable Q | model selection table |
| Global search (if PSO used) | same result for several seeds; convergence curve flat; not on a bound | `pso_convergence.png` |
| Reproducible | same `params.json` on a second run | `pytest tests/test_pipeline.py` |

## 5. Report

- Give the recommended model and its parameters with units (mOhm, s, F, Ah).
- List every WARN/FAIL and what it means physically.
- Say clearly which parameters are NOT identifiable from this data.
- Add open questions to `notes/agent_log.md`.
